/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author A216697
 */
public class EnrollEmployee {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        BankEmployee bob = new BankEmployee("Bob", 10, 30, 30000, "active");
        BankEmployee jerry = new BankEmployee("Jerry", 20, 20, 20000);
        BankEmployee tom = new BankEmployee("Tom", 30, 40, 50000);
        
        bob.displayEmployee();
        jerry.displayEmployee();
        tom.displayEmployee();
    }
    
}
