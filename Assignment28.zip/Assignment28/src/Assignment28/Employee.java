package Assignment28;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author A216697
 */
public abstract class Employee implements IEmployee {
    private String name;
    private int employeeType;
    private int salary;
    private int age;
    private boolean active = false;
    
    
    public Employee (String name, int employeeType, int salary, int age){
        this.name = name;
        this.employeeType = employeeType;
        this.salary = salary;
        this.age = age;
 
    }
    public void displayEmployee(){
        System.out.println(name + "," + employeeType + "," + salary + "," + age + "," + active);
    }
    
    public void activateEmployee(){
        
        active = true;       
        
    }
    
    public void deactivateEmployee(){
        active = false;
    }

    public void setSalary(int amount)throws Exception{
        if (amount< 10000){
            throw new Exception("salary too low");
        }
        else if (amount > 100000){
        throw new Exception ("salary too high");
        }
        else if (employeeType== MANANGER && salary < 20000){
            throw new Exception ("salary not enough");
        }
        else if (employeeType== DEVELOPER && salary < 30000){
            throw new Exception ("salary out of range");
        }
        else if (employeeType== EXEC && salary < 50000){
            throw new Exception ("salary not in range");
        }
        this.salary = salary;
    }
    
    public String toString(){
        return name + "," + employeeType + "," + salary + "," + age + "," + active;
    }
    @Override
    
    
}
