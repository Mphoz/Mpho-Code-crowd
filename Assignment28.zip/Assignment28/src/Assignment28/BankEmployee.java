package Assignment28;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author A216697
 */
public class BankEmployee extends Employee {
    private String bankName;
    
    
    public BankEmployee(String name, int employeeType, int age, int salary, boolean active){
        super(name, employeeType, salary, age,active);
        this.bankName = name;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }
    
    public void displayEmployee(){
        System.out.println(bankName);
        super.displayEmployee();
    }
    public String toString(){
        String details = super.toString();
        return bankName + "," + details;
    }

    @Override
    public void activateEmployee() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void deactiveEmployee() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}

    

