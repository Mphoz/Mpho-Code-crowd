/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author A216697
 */
public abstract class Employee implements IEmployee {
    private String name;
    private int employeeType;
    private int salary;
    private int age;
    private boolean active = false;
    
    
    public Employee (String name, int employeeType, int salary, int age, boolean active){
        this.name = name;
        this.employeeType = employeeType;
        this.salary = salary;
        this.age = age;
        this.active = active;
      
    }
    public void displayEmployee(){
        System.out.println(name + "," + employeeType + "," + salary + "," + age + "," + active);
    }
    
    public void activateEmployee(){
        
        boolean activateEmployee;       
        
    }
    
    public void deactivateEmployee(){
        
    }

    public void setSalary(int amount)throws Exception{
        if (amount< 10000){
            throw new Exception("salary too low");
        }
        if (amount > 100000){
        throw new Exception ("salary too high");
        }
        if (employeeType== MANANGER && salary < 20000){
            throw new Exception ("salary not enough");
        }
        if (employeeType== DEVELOPER && salary < 30000){
            throw new Exception ("salary out of range");
        }
        if (employeeType== EXEC && salary < 50000){
            throw new Exception ("salary not in range");
        }
        this.salary = salary;
    }
    
    public String toString(){
        return name + "," + employeeType + "," + salary + "," + age + "," + active;
    }
}
